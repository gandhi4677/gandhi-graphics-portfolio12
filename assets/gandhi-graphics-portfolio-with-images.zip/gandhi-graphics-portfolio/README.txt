GANDHI GRAPHIC DESIGNER PORTFOLIO
================================

This updated website includes six original SVG design concept images:
- Wedding invitation
- Birthday invitation
- Baby shower card
- Engagement invitation
- Business logo concept
- Business banner

The uploaded Gandhi logo and portrait are in assets/ as logo.png and profile.png.

The new gallery items are starter design concepts made for this portfolio.
Please customise them in a design editor or replace them with your own finished
work before presenting them as completed client projects.

Publish:
1. Extract this ZIP.
2. Upload the contents to your GitHub repository, preserving the assets folder.
3. Go to Settings > Pages.
4. Select Deploy from a branch, branch main, folder /(root), then Save.
5. Wait for GitHub Pages to publish your website.
